import java.awt.Color;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;








public class FitnessPlanGenerator extends JFrame {
	 // Anfang Attribute GUI
	  private JLabel lname = new JLabel();
	  private JLabel lfitness = new JLabel();
	  private JLabel lziel = new JLabel();
	  private JLabel ltage = new JLabel();
	  private JLabel lort = new JLabel();
	  private JLabel Lprofiltage = new JLabel();
	  private JLabel Lprofilziel = new JLabel();
	  private JLabel Lprofilort = new JLabel();
	  private JLabel atage = new JLabel();
	  private JLabel aort = new JLabel();
	  private JLabel aziel = new JLabel();
	  protected JTextField ename = new JTextField();
	  String [] tage = {"1","2","3","4","5","6"};
	  JComboBox boxtage = new JComboBox(tage);
	  protected JButton bspeichern = new JButton();
	  protected JButton berstellen = new JButton();
	  protected JTextArea aplan = new JTextArea("");
	    protected JScrollPane aplanScrollPane = new JScrollPane(aplan); 
	  private JLabel lprofil = new JLabel();
	  protected JComboBox<FitnessPlanGenerator> boxprofil = new JComboBox<FitnessPlanGenerator>();
	    private DefaultComboBoxModel<FitnessPlanGenerator> boxprofilModel = new DefaultComboBoxModel<FitnessPlanGenerator>();
	  protected JRadioButton rbmuskelaufbau = new JRadioButton();
	  protected JRadioButton rbabnehmen = new JRadioButton();
	  protected JRadioButton rbGym = new JRadioButton();
	  protected JRadioButton rbHome = new JRadioButton();
	  protected ButtonGroup ort = new ButtonGroup();
	  protected ButtonGroup ziel = new ButtonGroup();
	  // Ende Attribute GUI
	  //Anfang Attribute Fitness Plan
	  private ArrayList<FitnessPlanGenerator> pers = new ArrayList<FitnessPlanGenerator>();
		protected String name;
		protected int trainingsTage;
		protected String trainingsZiel;
		protected boolean trainingsOrt;
	  // Ende Attribute
		
	  // Konstruktor	
		public FitnessPlanGenerator(String name, int trainingsTage, String trainingsZiel, boolean trainingsOrt)
				throws HeadlessException {
			super();
			this.name = name;
			this.trainingsTage = trainingsTage;
			this.trainingsZiel = trainingsZiel;
			this.trainingsOrt = trainingsOrt;
		}
		
		// main Methode
		  public static void main(String[] args) {
			  FitnessPlanGenerator k = new FitnessPlanGenerator();
			  k.initObjekte();
			  
		  } 
		
		  // Funktion vom Speichern Button
		  public void bspeichern_ActionPerformed(ActionEvent evt) {
			  
			 	try {
			 			// auslesen der von Benutzer eingetragenen Daten
				        String name = auslesenName();
					    int tage = auslesenTage();
					    String traziel = auslesenZiel();
					    boolean ort = auslesenOrt();
					    // �berpr�fung auf fehlerhafte eingabe
					    if(name.length() > 0 && traziel.equals("Muskelaufbau") | traziel.equals("Abnehmen") && rbGym.isSelected() | rbHome.isSelected()) {
				        FitnessPlanGenerator pers1 = new FitnessPlanGenerator(name, tage, traziel, ort);
			            pers.add(pers1);
			            updateBox();
					    }
					    else {
					    	JOptionPane.showMessageDialog(FitnessPlanGenerator.this, "Fehler: Unvollstandige Eingabe");
					    }
			 		
			 	} 
			  
			 	catch (NullPointerException e) {
			           
			        	JOptionPane.showMessageDialog(FitnessPlanGenerator.this, "Fehler: Unvollstandige Eingabe");

			 	}
		  } 
		  
		  // Funktion von Erstellen Button
		  // Algorithmus f�r zuweisung des richtigen Trainingsplan
		  public void berstellen_ActionPerformed(ActionEvent evt) {
			  	String text = "";
				String text2 = "";
				String text3 = "";
				String text4 = "";
				String text5 = "";
				String text6 = "";
				String text7 = "";
				String text8 = "";
				String text9 = "";
				String text10 = "";
				String text11 = "";
				String text12 = "";
				FitnessPlanGenerator p = (FitnessPlanGenerator) boxprofil.getSelectedItem();
				try {
					 if(p.trainingsTage == 1 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == true) {
							text = "Tag 1 Ganzk�rper Training:";
							text2 = gkGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 2 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == true) {
							text = "Tag 1 Oberk�rper Training:";
							text2 = okGym();
							text3 = "Tag 2 Unterk�rper Training:";
							text4 = lgGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
							
						}
						if(p.trainingsTage == 3 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == true) {
							text = "Tag 1 Push Day:";
							text2 = pushdayGym();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayGym();
							text5 = "Tag 3 Leg Day:";
							text6 = lgGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 4 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == true) {
							text = "Tag 1 Push Day:";
							text2 = pushdayGym();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayGym();
							text5 = "Tag 3 Leg Day:";
							text6 = lgGym();
							text7 = "Tag 4 Ganzk�rper Training:";
							text8 = gkGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 5 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == true) {
							text = "Tag 1 Leg Day:";
							text2 = lgGym();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayGym();
							text5 = "Tag 3 Push Day:";
							text6 = pushdayGym();
							text7 = "Tag 4 Oberk�rper Training:";
							text8 = okGym();
							text9 = "Tag 5 Unterk�rper Training:";
							text10 = lgGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 6 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == true) {
							text = "Tag 1 Push Day:";
							text2 = pushdayGym();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayGym();
							text5 = "Tag 3 Leg Day:";
							text6 = lgGym();
							text7 = "Tag 4 Push Day:";
							text8 = pushdayGym();
							text9 = "Tag 5 Pull Day:";
							text10 = pulldayGym();
							text11 = "Tag 6 Leg Day:";
							text12 = lgGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 1 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == true) {
							text = "Tag 1 Cardio:";
							text2 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 2 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == true) {
							text = "Tag 1 Ganzk�rper Training:";
							text2 = gkGym();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 3 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == true) {
							text = "Tag 1 Cardio:";
							text2 = cardio();
							text3 = "Tag 2 Ganzk�rper Training:";
							text4 = pulldayGym();
							text5 = "Tag 3 Cardio:";
							text6 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 4 && p. trainingsZiel.equals("Abnehmen") && p.trainingsOrt == true) {
							text = "Tag 1 Oberk�rper Training:";
							text2 = okGym();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							text5 = "Tag 3 Unterk�rper Training:";
							text6 = lgGym();
							text7 = "Tag 4 Cardio:";
							text8 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 5 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == true) {
							text = "Tag 1 Push Day:";
							text2 = pushdayGym();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							text5 = "Tag 3 Pull Day:";
							text6 = pulldayGym();
							text7 = "Tag 4 Carido:";
							text8 = cardio();
							text9 = "Tag 5 Leg Day:";
							text10 = lgGym();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 6 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == true) {
							text = "Tag 1 Push Day:";
							text2 = pushdayGym();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							text5 = "Tag 3 Pull Day:";
							text6 = pulldayGym();
							text7 = "Tag 4 Cardio:";
							text8 = cardio();
							text9 = "Tag 5 Leg Day:";
							text10 = lgGym();
							text11 = "Tag 6 Cardio:";
							text12 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 1 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == false) {
							text = "Tag 1 Ganzk�rper Training:";
							text2 = gkHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 2 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == false) {
							text = "Tag 1 Oberk�rper Training:";
							text2 = okHome();
							text3 = "Tag 2 Unterk�rper Training:";
							text4 = lgHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 3 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == false) {
							text = "Tag 1 Push Day:";
							text2 = pushdayHome();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayHome();
							text5 = "Tag 3 Leg Day:";
							text6 = lgHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 4 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == false) {
							text = "Tag 1 Push Day:";
							text2 = pushdayHome();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayHome();
							text5 = "Tag 3 Leg Day:";
							text6 = lgHome();
							text7 = "Tag 4 Ganzk�rper Training:";
							text8 = gkHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 5 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == false) {
							text = "Tag 1 Leg Day:";
							text2 = lgHome();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayHome();
							text5 = "Tag 3 Push Day:";
							text6 = pushdayHome();
							text7 = "Tag 4 Oberk�rper Training:";
							text8 = okHome();
							text9 = "Tag 5 Unterk�rper Training:";
							text10 = lgHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 6 && p.trainingsZiel.equals("Muskelaufbau") && p.trainingsOrt == false) {
							text = "Tag 1 Push Day:";
							text2 = pushdayHome();
							text3 = "Tag 2 Pull Day:";
							text4 = pulldayHome();
							text5 = "Tag 3 Leg Day:";
							text6 = lgHome();
							text7 = "Tag 4 Push Day:";
							text8 = pushdayHome();
							text9 = "Tag 5 Pull Day:";
							text10 = pulldayHome();
							text11 = "Tag 6 Leg Day:";
							text12 = lgHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 1 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == false) {
							text = "Tag 1 Cardio:";
							text2 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 2 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == false) {
							text = "Tag 1 Ganzk�rper Training:";
							text2 = gkHome();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 3 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == false) {
							text = "Tag 1 Cardio:";
							text2 = cardio();
							text3 = "Tag 2 Ganzk�rper Training:";
							text4 = pulldayHome();
							text5 = "Tag 3 Cardio:";
							text6 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 4 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == false) {
							text = "Tag 1 Oberk�rper Training:";
							text2 = okHome();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							text5 = "Tag 3 Unterk�rper Training:";
							text6 = lgHome();
							text7 = "Tag 4 Cardio:";
							text8 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 5 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == false) {
							text = "Tag 1 Push Day:";
							text2 = pushdayHome();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							text5 = "Tag 3 Pull Day:";
							text6 = pulldayHome();
							text7 = "Tag 4 Carido:";
							text8 = cardio();
							text9 = "Tag 5 Leg Day:";
							text10 = lgHome();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
						if(p.trainingsTage == 6 && p.trainingsZiel.equals("Abnehmen") && p.trainingsOrt == false) {
							text = "Tag 1 Push Day:";
							text2 = pushdayHome();
							text3 = "Tag 2 Cardio:";
							text4 = cardio();
							text5 = "Tag 3 Pull Day:";
							text6 = pulldayHome();
							text7 = "Tag 4 Cardio:";
							text8 = cardio();
							text9 = "Tag 5 Leg Day:";
							text10 = lgHome();
							text11 = "Tag 6 Cardio:";
							text12 = cardio();
							aplan.setText(text+"\n"+text2+"\n"+text3+"\n"+text4+"\n"+text5+"\n"+text6+"\n"+text7+"\n"+text8+"\n"+text9+"\n"+text10+"\n"+text11+"\n"+text12);
						}
				}
				catch (NumberFormatException e) {
		           
		            aplan.setText("Unvollstandige Eingabe");
				
				}
		  }
				
				
				
		    
		   
		  
		  // Objekt umwandeln in String
		  public String toString() {
				return name;
			}
		  
		  // Auslesen von Namens Feld
			public String auslesenName() {
				name = ename.getText();
				return name;
			}
			
			// Auslesen von Tages Feld
			public int auslesenTage() {
				int trainingsTage = Integer.parseInt(boxtage.getSelectedItem().toString());
				return trainingsTage;
			}
			
			// Auslesen von Ziel Radiobuttons
			public String auslesenZiel() {
				trainingsZiel = ziel.getSelection().getActionCommand();
				return trainingsZiel;
			}
			
			// Auslesen von Radiobutton f�r Trainingsort
			public boolean auslesenOrt() {
			
				if(rbGym.isSelected() && rbGym.getActionCommand().equals("Gym")) {
					trainingsOrt = true;
					
				}
				
				if(rbHome.isSelected() && rbHome.getActionCommand().equals("Home")) {
					trainingsOrt = false;
				
				}
				
				return trainingsOrt;
			}
			
			
			// Profil in JCombobox eintragen
			public void updateBox() {
				for(int i = 0; i < pers.size(); i++) {
					boxprofil.removeAllItems();
				    for(FitnessPlanGenerator p: pers){
				        boxprofil.addItem(p);
				        }
				}
			}
			//Erstellung der 3 Objekte in der Aufgabenstellung 
			public void initObjekte() {
				FitnessPlanGenerator anf = new FitnessPlanGenerator("Anf�nger", 2, "Muskelaufbau", true);
				FitnessPlanGenerator casual = new FitnessPlanGenerator("Fortgeschrittener", 4, "Muskelaufbau", true);
				FitnessPlanGenerator profi = new FitnessPlanGenerator("Profi", 6, "Muskelaufbau", true);
				pers.add(anf);
				pers.add(casual);
				pers.add(profi);
				updateBox();
			}
			// Komplette GUI 
			public FitnessPlanGenerator() { 
			    // Frame-Initialisierung
			    super();
			    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			    int frameWidth = 800; 
			    int frameHeight = 820;
			    setSize(frameWidth, frameHeight);
			    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
			    int x = (d.width - getSize().width) / 2;
			    int y = (d.height - getSize().height) / 2;
			    setLocation(x, y);
			    setTitle("Fitness Plan Generator");
			    setResizable(false);
			    Container cp = getContentPane();
			    cp.setLayout(null);
			    // Hinzuf�gen der Komponenten
			     
			    cp.setBackground(Color.WHITE);
			    lname.setBounds(40, 60, 150, 28);
			    lname.setText("Name:");
			    lname.setOpaque(false);
			    lname.setForeground(Color.BLACK);
			    lname.setHorizontalAlignment(SwingConstants.CENTER);
			    lname.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(lname);
			    lfitness.setBounds(0, 0, 800, 34);
			    lfitness.setText("Fitness Plan Generator");
			    lfitness.setFont(new Font("Arial", Font.BOLD, 26));
			    lfitness.setHorizontalAlignment(SwingConstants.CENTER);
			    cp.add(lfitness);
			    lziel.setBounds(40, 180, 150, 28);
			    lziel.setText("Trainingsziel?");
			    lziel.setHorizontalAlignment(SwingConstants.CENTER);
			    lziel.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(lziel);
			    ltage.setBounds(40, 120, 200, 28);
			    ltage.setText("Trainingstage in der Woche?");
			    ltage.setHorizontalAlignment(SwingConstants.CENTER);
			    ltage.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(ltage);
			    lort.setBounds(40, 240, 150, 28);
			    lort.setText("Trainingsort?");
			    lort.setHorizontalAlignment(SwingConstants.CENTER);
			    lort.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(lort);
			    Lprofiltage.setBounds(40, 420, 210, 28);
			    Lprofiltage.setText("Trainingstage in der Woche:");
			    Lprofiltage.setHorizontalAlignment(SwingConstants.CENTER);
			    Lprofiltage.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(Lprofiltage);
			    Lprofilziel.setBounds(320, 420, 120, 28);
			    Lprofilziel.setText("Trainingsziel:");
			    Lprofilziel.setHorizontalAlignment(SwingConstants.CENTER);
			    Lprofilziel.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(Lprofilziel);
			    Lprofilort.setBounds(540, 420, 120, 28);
			    Lprofilort.setText("Trainingsort:");
			    Lprofilort.setHorizontalAlignment(SwingConstants.CENTER);
			    Lprofilort.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(Lprofilort);
			    ename.setBounds(270, 60, 150, 28);
			    ename.setFont(new Font("Arial", Font.PLAIN, 14));
			    ename.setForeground(Color.BLACK);
			    ename.setHorizontalAlignment(SwingConstants.CENTER);
			    cp.add(ename);
			    boxtage.setBounds(270, 120, 50, 28);			   
			    cp.add(boxtage);
			    bspeichern.setBounds(570, 240, 100, 28);
			    bspeichern.setText("Speichern");
			    bspeichern.setMargin(new Insets(2, 2, 2, 2));
			    bspeichern.addActionListener(new ActionListener() { 
			      public void actionPerformed(ActionEvent evt) { 
			        bspeichern_ActionPerformed(evt);
			      }
			    });
			    bspeichern.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(bspeichern);
			    berstellen.setBounds(570, 350, 100, 28);
			    berstellen.setText("Erstellen");
			    berstellen.setMargin(new Insets(2, 2, 2, 2));
			    berstellen.addActionListener(new ActionListener() { 
			      public void actionPerformed(ActionEvent evt) { 
			        berstellen_ActionPerformed(evt);
			      }
			    });
			    berstellen.setForeground(Color.BLACK);
			    berstellen.setFont(new Font("Arial", Font.BOLD, 14));
			    cp.add(berstellen);
			    aplanScrollPane.setBounds(13, 497, 758, 276);
			    aplan.setFont(new Font("Arial", Font.PLAIN, 14));
			    aplan.setForeground(Color.BLACK);
			    aplan.setTabSize(90);
			    aplan.setEnabled(false);
			    aplan.setDisabledTextColor(Color.BLACK);
			    cp.add(aplanScrollPane);
			    atage.setBounds(40, 450, 210, 28);
			    atage.setHorizontalAlignment(SwingConstants.CENTER);
			    atage.setFont(new Font("Arial", Font.PLAIN, 14));
			    cp.add(atage);
			    aort.setBounds(540, 450, 120, 28);
			    aort.setHorizontalAlignment(SwingConstants.CENTER);
			    aort.setFont(new Font("Arial", Font.PLAIN, 14));
			    cp.add(aort);
			    aziel.setBounds(320, 450, 120, 28);
			    aziel.setHorizontalAlignment(SwingConstants.CENTER);
			    aziel.setFont(new Font("Arial", Font.PLAIN, 14));
			    cp.add(aziel);
			    lprofil.setBounds(40, 350, 150, 28);
			    lprofil.setText("Profil:");
			    lprofil.setFont(new Font("Arial", Font.BOLD, 14));
			    lprofil.setHorizontalAlignment(SwingConstants.CENTER);
			    cp.add(lprofil);
			    boxprofil.setModel(boxprofilModel);
			    boxprofil.setBounds(270, 350, 150, 28);
			    boxprofil.setFont(new Font("Arial", Font.PLAIN, 14));
			    boxprofil.setForeground(Color.BLACK);
			    boxprofil.setBackground(Color.WHITE);
			    //zuweisung der Attribute vom ausgew�hlten Profil
			    boxprofil.addItemListener(new ItemListener() {
			    	public void itemStateChanged(ItemEvent e) {
			    		 if(e.getStateChange() == ItemEvent.SELECTED) {
			    			FitnessPlanGenerator p = (FitnessPlanGenerator) boxprofil.getSelectedItem();
			    			boolean ort1 = p.isTrainingsOrt();
		
			    			if(ort1 == true) {
			    				aort.setText("Gym");
			    			}
			    			if(ort1 == false) {
			    				aort.setText("Home");
			    			}
			    			
			    			aziel.setText(p.getTrainingsZiel());
			    			String tage = Integer.toString(p.getTrainingsTage());
			    			atage.setText(tage);
			    		 }
			    	}
			    });
			    ziel.add(rbmuskelaufbau);
			    ziel.add(rbabnehmen);
			    ort.add(rbGym);
			    ort.add(rbHome);
			    cp.add(boxprofil);
			    rbmuskelaufbau.setBounds(270, 180, 116, 28);
			    rbmuskelaufbau.setOpaque(false);
			    rbmuskelaufbau.setText("Muskelaufbau");
			    rbmuskelaufbau.setActionCommand("Muskelaufbau");
			    rbmuskelaufbau.setFont(new Font("Arial", Font.PLAIN, 14));
			    rbmuskelaufbau.setForeground(Color.BLACK);
			    cp.add(rbmuskelaufbau);
			    rbabnehmen.setBounds(420, 180, 116, 28);
			    rbabnehmen.setOpaque(false);
			    rbabnehmen.setText("Abnehmen");
			    rbabnehmen.setFont(new Font("Arial", Font.PLAIN, 14));
			    rbabnehmen.setActionCommand("Abnehmen");
			    cp.add(rbabnehmen);
			    rbGym.setBounds(270, 240, 116, 28);
			    rbGym.setOpaque(false);
			    rbGym.setText("Gym");
			    rbGym.setActionCommand("Gym");
			    rbGym.setFont(new Font("Arial", Font.PLAIN, 14));
			    cp.add(rbGym);
			    rbHome.setBounds(420, 240, 116, 28);
			    rbHome.setOpaque(false);
			    rbHome.setText("Home");
			    rbHome.setActionCommand("Home");
			    rbHome.setFont(new Font("Arial", Font.PLAIN, 14));
			    cp.add(rbHome);
			  
			    // Ende Komponenten
			    
			    setVisible(true);
			  } 
			
			
			// Methoden f�r Trainingsplan
			// Ganzk�rper Training im GYM
			public String gkGym() {
				String �1gkGym = "�bung 1: Flachbankdr�cken Maschine, S�tze: 3, Wiederholungen: 10"+"\n";
				String �2gkGym = "�bung 2: Butterfly, S�tze: 3, Wiederholungen: 10"+"\n";
				String �3gkGym = "�bung 3: Latzug zur Brust, S�tze: 3, Wiederholungen: 10"+"\n";
				String �4gkGym = "�bung 4: Rudern am Kabel sitzend, S�tze: 3, Wiederholungen: 10"+"\n";
				String �5gkGym = "�bung 5: Seitheben Kurzhanteln, S�tze: 3, Wiederholungen: 10"+"\n";
				String �6gkGym = "�bung 6: SZ Curls, S�tze: 3, Wiederholungen: 10"+"\n";
				String �7gkGym = "�bung 7: Trizepsdr�cken am Kabel, S�tze: 3, Wiederholungen: 10"+"\n";
				String �8gkGym = "�bung 8: Beinpresse, S�tze: 3, Wiederholungen: 10"+"\n";
				String �9gkGym = "�bung 9: Beincurls, S�tze: 3, Wiederholungen: 10"+"\n";
				String �10gkGym = "�bung 10: Crunch, S�tze: 3, Wiederholungen: 10"+"\n";
				return �1gkGym+�2gkGym+�3gkGym+�4gkGym+�5gkGym+�6gkGym+�7gkGym+�8gkGym+�9gkGym+�10gkGym;
			}
			// Ganzk�rper Training zu Hause
			public String gkHome() {
				String �1gkHome = "�bung 1: Liegest�tze S�tze: 3, Wiederholungen: 5 - 15"+"\n";
				String �2gkHome = "�bung 2: Squads ohne Gewicht , S�tze: 3, Wiederholungen: 10 - 25"+"\n";
				String �3gkHome = "�bung 3: Rudern an der Tischkante, S�tze: 3, Wiederholungen: 5 - 12"+"\n";
				String �4gkHome = "�bung 4: Wandsitzen (Beine 90�) , S�tze: 3, Wiederholungen: 30 - 50 sec"+"\n";
				String �5gkHome = "�bung 5: Crunches, S�tze: 3, Wiederholungen: 10 - 30"+"\n";
				return �1gkHome+�2gkHome+�3gkHome+�4gkHome+�5gkHome;
			}
			// Oberk�rper Training GYM
			public String okGym() {
				String �1okGym = "�bung 1: Bankdr�cken, S�tze: 3, Wiederholungen: 10"+"\n";
				String �2okGym = "�bung 2: Dips, S�tze: 3, Wiederholungen: 10"+"\n";
				String �3okGym = "�bung 3: Push ups, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �4okGym = "�bung 4: Rudern(Maschine oder Kabel), S�tze: 3, Wiederholungen: 10"+"\n";
				String �5okGym = "�bung 5: Military Press, S�tze: 3, Wiederholungen: 10"+"\n";
				String �6okGym = "�bung 6: Seitheben, S�tze: 3, Wiederholungen: 10"+"\n";
				String �7okGym = "�bung 7: SZ-Curls, S�tze: 3, Wiederholungen: 10"+"\n";
				String �8okGym = "�bung 8: Pushdowns, S�tze: 3, Wiederholungen: 10"+"\n";
				return �1okGym+�2okGym+�3okGym+�4okGym+�5okGym+�6okGym+�7okGym+�8okGym;
			}
			// Oberk�rper Training zu Hause
			public String okHome() {
				String �1okHome = "�bung 1: breite Liegest�tze, S�tze: 3, Wiederholungen: 10 - 15"+"\n";
				String �2okHome = "�bung 2: enge Liegest�tze, S�tze: 3, Wiederholungen: 10 - 15"+"\n";
				String �3okHome = "�bung 3: Kopf�ber Schulterdr�cken, S�tze: 3, Wiederholungen: 10 - 15"+"\n";
				String �4okHome = "�bung 4: Dips, S�tze: 3, Wiederholungen: 10 - 15"+"\n";
				String �5okHome = "�bung 5: Crunches, S�tze: 3, Wiederholungen: 10 - 20"+"\n"; 
				return �1okHome+�2okHome+�3okHome+�4okHome+�5okHome;
			}
			// Beintraining GYM
			public String lgGym() {
				String �1lgGym = "�bung 1: Kreuzheben, S�tze: 3, Wiederholungen: 10"+"\n";
				String �2lgGym = "�bung 2: Beinpresse, S�tze: 3, Wiederholungen: 10"+"\n";
				String �3lgGym = "�bung 3: Ausfallschritte mit Gewichten, S�tze: 3, Wiederholungen: 10"+"\n";
				String �4lgGym = "�bung 4: Wandenheben am Ger�t, S�tze: 3, Wiederholungen: 10"+"\n";
				return �1lgGym+�2lgGym+�3lgGym+�4lgGym;
			}
			// Beintraining zu Hause
			public String lgHome() {
				String �1lgHome = "�bung 1: Squats, S�tze: 3, Wiederholungen: 10 - 30"+"\n";
				String �2lgHome = "�bung 2: Slow Walk, S�tze: 3, Wiederholungen: 30 - 45 sec"+"\n";
				String �3lgHome = "�bung 3: Ausfallschritte, S�tze: 3, Wiederholungen: 10 - 15"+"\n";
				String �4lgHome = "�bung 4: Wandenheben am Ger�t, S�tze: 3, Wiederholungen: 10 - 35"+"\n";
				return �1lgHome+�2lgHome+�3lgHome+�4lgHome;
			}
			// Push Day GYM
			public String pushdayGym() {
				String �1pushGym = "�bung 1: Bankdr�cken mit LH, S�tze: 3, Wiederholungen: 10"+"\n";
				String �2pushGym = "�bung 2: Schr�gbankdr�cken mit KH, S�tze: 3, Wiederholungen: 10"+"\n";
				String �3pushGym = "�bung 3: Butterfly, S�tze: 3, Wiederholungen: 10"+"\n";
				String �4pushGym = "�bung 4: Seitheben mit KH, S�tze: 3, Wiederholungen: 10"+"\n";
				String �5pushGym = "�bung 5: enges Bankdr�cken mit SZ-Stange, S�tze: 3, Wiederholungen: 10"+"\n";
				return �1pushGym+�2pushGym+�3pushGym+�4pushGym+�5pushGym;
			}
			// Push Day zu Hause
			public String pushdayHome() {
				String �1pushHome = "�bung 1: Breite Liegest�tze, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �2pushHome = "�bung 2: Dips, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �3pushHome = "�bung 3: �berkopf Schulterdr�cken, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �4pushHome = "�bung 4: enge Liegest�tze, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �5pushHome = "�bung 5: Butterfly ohne Gewicht, S�tze: 3, Wiederholungen: 10 - 20"+"\n";
				return �1pushHome+�2pushHome+�3pushHome+�4pushHome+�5pushHome;
			}
			// Pull Day GYM
			public String pulldayGym() {
				String �1pullGym = "�bung 1: Push ups, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �2pullGym = "�bung 2: Enges Kabelrudern, S�tze: 3, Wiederholungen: 10"+"\n";
				String �3pullGym = "�bung 3: Rudermaschine, S�tze: 3, Wiederholungen: 10"+"\n";
				String �4pullGym = "�bung 4: Butterfly Reverse, S�tze: 3, Wiederholungen: 10"+"\n";
				String �5pullGym = "�bung 5: Langhantelcurls, S�tze: 3, Wiederholungen: 10"+"\n";
				return �1pullGym+�2pullGym+�3pullGym+�4pullGym+�5pullGym;
			}
			// Pull Day zu Hause
			public String pulldayHome() {
				String �1pullHome = "�bung 1: Push ups, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �2pullHome = "�bung 2: Pull ups, S�tze: 3, Wiederholungen: MAX"+"\n";
				String �3pullHome = "�bung 3: Rudern an Tischkante, S�tze: 3, Wiederholungen: 10"+"\n";
				String �4pullHome = "�bung 4: Butterfly Reverse gegen Schwerkraft, S�tze: 3, Wiederholungen: 10"+"\n";
				String �5pullHome = "�bung 5: Curls mit eigenen Wiederstand, S�tze: 3, Wiederholungen: 10"+"\n";
				return �1pullHome+�2pullHome+�3pullHome+�4pullHome+�5pullHome;
			}
			// Cardio Training
			public String cardio() {
				String einleitung1 = "Jede �bung 45 sec ausf�hren danach 15 sec Pausen und dann bei der n�chsten �bung starten."+"\n";
				String einleitung2 = "Jede �bung jeweils in 5 Runden durchf�hren."+"\n";
				String einleitung3 = "Nach jeder Runde 1 min pause einlegen"+"\n";
				String �1cardio = "�bung 1: Burpees"+"\n";
				String �2cardio = "�bung 2: Jumping Jacks"+"\n";
				String �3cardio = "�bung 3: Wall climber"+"\n";
				String �4cardio = "�bung 4: Squads"+"\n";
				String �5cardio = "�bung 5: Shadow Boxing"+"\n";
				return einleitung1+einleitung2+einleitung3+�1cardio+�2cardio+�3cardio+�4cardio+�5cardio;
			}

			
			//get und setter Methoden
			public int getTrainingsTage() {
				return trainingsTage;
			}

			public void setTrainingsTage(int trainingsTage) {
				this.trainingsTage = trainingsTage;
			}

			public String getTrainingsZiel() {
				return trainingsZiel;
			}

			public void setTrainingsZiel(String trainingsZiel) {
				this.trainingsZiel = trainingsZiel;
			}

			public boolean isTrainingsOrt() {
				return trainingsOrt;
			}

			public void setTrainingsOrt(boolean trainingsOrt) {
				this.trainingsOrt = trainingsOrt;
			}
			
			
}
